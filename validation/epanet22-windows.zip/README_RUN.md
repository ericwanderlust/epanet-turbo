# EPANET-Turbo v2.8.1-preview.7 — windows-x64 — EPANET 2.2 compatible

Technical preview with the WNTR adapter, fast reader and benchmark and PyArmor-protected `turbo_bulk.BulkAPI` for CPython 3.11 and 3.12. Native library: `native/windows_x86_64/epanet2.dll`. 

Install the included requirements if using Python, then add the matching `python/cp311` or `python/cp312` folder to `PYTHONPATH`. PyArmor itself is not required by users. Keep the native library and bundled OpenMP runtime together.

`BulkAPI.from_wntr(toolkit)` attaches to an open WNTR Toolkit project. `BulkAPI(library, project)` also accepts an already-open native project. The helper automatically reads the library version and probes capabilities; `version` and `capabilities` disclose whether reads/writes use Turbo bulk, EPANET 2.3 bulk, or scalar fallback. Official 2.2 and older libraries without bulk exports remain usable with scalar calls, which do not provide bulk speedup. Existing WNTR `run_sim` is not automatically changed to a bulk workflow.

`node_values()` / `link_values()` return NumPy float64 arrays in native Toolkit units. `set_node_values(property, indices, values)` and `set_link_values(...)` use valid 1-based indices; errors can leave earlier property writes applied, matching native Toolkit behavior. `set_demand_multiplier(factor)` always uses the standard EPANET demand option, avoiding the incorrect multiplier export in older Turbo 2.3 releases. Keep the project open while the helper is used.

Normal full simulations preserve improved head differences for headloss and friction. Reusing any standard `.hyd` retains its single-precision head limitation. CHOLMOD / M9 takeover is disabled. See the GitHub Release and README for usage, performance and platform validation.

Fast WNTR I/O: `TurboSimulator(network, library, fast_io=True)` uses the fast writer and reader on WNTR 1.4.0. See the GitHub README for the batch scenario API and validation.

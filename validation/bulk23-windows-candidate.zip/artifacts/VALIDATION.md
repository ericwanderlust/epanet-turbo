# Validation status

Technical preview candidate: windows-x64. Target test environment: Windows Server 2022 x64. See Release notes for completed tests.

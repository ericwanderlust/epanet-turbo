# Runtime source and build provenance

The 2.3.3 engine is based on OWA EPANET 2.3.3 with EPANET-Turbo changes, including low-flow output precision.
https://github.com/OpenWaterAnalytics/EPANET/releases/tag/v2.3.3

The bundled OpenMP runtime licenses are in licenses/. The public repository does not contain the exact native C build source.

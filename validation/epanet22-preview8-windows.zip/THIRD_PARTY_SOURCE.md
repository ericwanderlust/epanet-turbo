# Runtime source and build provenance

2.2 engine compiled with Debian GCC 12.2.0 / MinGW-w64. Bundled runtime: Debian gcc-mingw-w64 25.2 and MinGW-w64 10.0.0.
https://sources.debian.org/src/gcc-mingw-w64/25.2/
https://sources.debian.org/src/mingw-w64/10.0.0-3/

The engine is based on EPANET 2.2 with Turbo OpenMP, output-precision and bulk API changes. The fast reader is adapted from WNTR 1.4.0; see licenses/wntr.txt.

# Pyarmor 9.2.5 (basic), 012404, 2026-11-03T23:50:15.002395
from .pyarmor_runtime import __pyarmor__

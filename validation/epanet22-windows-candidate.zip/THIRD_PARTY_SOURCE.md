# Runtime source and build provenance

GNU GCC runtime: Debian gcc-mingw-w64 25.2 and GCC 12.2.0; MinGW-w64 10.0.0.
https://sources.debian.org/src/gcc-mingw-w64/25.2/
https://sources.debian.org/src/gcc-12/12.2.0-14%2Bdeb12u1/
https://sources.debian.org/src/mingw-w64/10.0.0-3/

The 2.2 engine is unchanged from v2.8.1-preview.2. The optional fast reader is adapted from WNTR 1.4.0; see licenses/wntr.txt.

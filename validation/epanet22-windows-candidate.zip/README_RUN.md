# EPANET-Turbo Windows x64 candidate

Test candidate for EPANET 2.2 and WNTR 1.4.0. Install requirements.txt and use the matching CPython 3.11 or 3.12 protected runtime. Fresh hydraulic simulations preserve pipe head differences for friction reporting; when reusing a standard .hyd file, original single-precision limits remain. The .hyd file format is unchanged. This candidate is not a release.

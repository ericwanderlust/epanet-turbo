# Validation status

Candidate for Windows x64 native testing.

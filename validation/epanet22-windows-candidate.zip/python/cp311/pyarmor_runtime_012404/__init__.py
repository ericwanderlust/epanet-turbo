# Pyarmor 9.2.5 (basic), 012404, 2026-11-03T19:10:44.680192
from .pyarmor_runtime import __pyarmor__

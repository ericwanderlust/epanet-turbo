# Validation status

Preview candidate: windows-x64. See the release notes for target-platform test results.

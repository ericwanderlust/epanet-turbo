# 🏎️ EPANET-Turbo v2.8.1-preview.8 — windows-x64 — EPANET 23

Technical preview / 技术预览版. Platform / 架构: **windows-x64**. Native engine: `native/windows_x86_64/epanet2.dll`.

EPANET 2.3.3. M9 assembly remains disabled for this engine. CHOLMOD and external solver takeover remain disabled.

For the Rust API on Windows, use ASCII model and temporary-report paths; set TMP/TEMP before starting Python if necessary.

The 2.3 package includes the encrypted version-aware BulkAPI. Python code is PyArmor protected; users do not need PyArmor. Install `requirements.txt` and add `python/cp311` or `python/cp312` to `PYTHONPATH` to match CPython 3.11 or 3.12. Keep the native engine and bundled OpenMP libraries together.

🦀 `epanet_rs` is an optional compiled Rust API for EPANET 2.2 and 2.3. It returns hydraulic times and flat pressure/flow arrays in native Toolkit units; it does not replace WNTR's complete results or water-quality calculation. The experimental Rust WNTR reader is not automatically enabled.

```python
from pathlib import Path
import sys

bundle = Path('/path/to/unpacked-package')
sys.path.insert(0, str(bundle / 'python' / f'cp{sys.version_info.major}{sys.version_info.minor}'))
from epanet_rs import EpanetContext

context = EpanetContext(str(bundle / 'native/windows_x86_64/epanet2.dll'))
try:
    context.open('your-model.inp')
    times, pressures, flows, stats = context.run_hydraulics(threads=4)
    print(times, stats['hydraulic_warnings'])
finally:
    context.close()
```

Warnings are reported in `stats['hydraulic_warnings']`; native hard errors raise `RuntimeError`. Bulk writes stop at the first error and earlier writes may already be applied. One context cannot be used concurrently. Standard `.hyd` reuse retains single-precision head limitations.

See the GitHub README and Release for WNTR examples, tested architectures, performance measurements and known limits.

## 中文使用说明 🇨🇳

解压后安装 `requirements.txt`，按 CPython 3.11 / 3.12 选择对应的 `python/cp311` / `python/cp312` 目录。Python 脚本已由 PyArmor 保护，使用者不需要安装 PyArmor。将原生库与随包的 OpenMP 运行库保存在同一目录。2.2 包支持 WNTR 1.4.0 快速读写、多场景和自动识别批量接口；2.3 包提供自动识别批量接口。两个包均提供可选的 Rust 水力接口。

上方 Rust 示例返回模型原生单位的压力与流量数组，完整 WNTR 结果请使用 2.2 包的 WNTR 接口。具体调用、实测性能和已知边界请查看 GitHub README。CHOLMOD 不在本版接管水力求解。

Windows Rust 接口请使用 ASCII 模型与临时路径，必要时在启动 Python 前设置 `TMP` / `TEMP`。

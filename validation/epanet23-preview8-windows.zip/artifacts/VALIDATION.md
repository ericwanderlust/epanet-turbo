# Preview validation / 预览验证

- Target / 环境: Windows Server 2022 x64 GitHub-hosted VM.
- CPython 3.11 and 3.12: protected WNTR fast I/O, demand scenarios and 2.2/2.3 automatic bulk access; Rust hydraulics against stock 2.2 and Turbo 2.2/2.3.
- WNTR adapter and demand scenarios require the 2.2 package; the 2.3 package provides bulk access and the Rust API.
- CHOLMOD and external solver takeover are disabled. This is a technical preview; verify results for your own models.
- Windows validation uses a virtual machine; physical Windows hardware has not been tested.
